USE `olympics`;

--1-Listar todas las ciudades sede de los juegos olímpicos de verano junto con su año,

--de más reciente a menos reciente (1p)

SELECT
    city.city_name,
    games.games_year
FROM olympics.games
    JOIN olympics.games_competitor ON games.id = games_competitor.games_id
    JOIN olympics.person ON games_competitor.person_id = person.id
    JOIN olympics.person_region ON person.id = person_region.person_id
    JOIN olympics.noc_region ON person_region.region_id = noc_region.id
    JOIN olympics.city ON noc_region.id = city.id
WHERE games.season = 'Summer'
GROUP BY
    city.city_name,
    games.games_year
ORDER BY games.games_year DESC;

--2- Obtener el ranking de los 10 países con más medallas de oro en fútbol (1.5p),

SELECT
    noc_region.region_name AS Country,
    COUNT(*) AS Gold_Medals
FROM olympics.medal
    JOIN olympics.competitor_event ON medal.id = competitor_event.medal_id
    JOIN olympics.event ON competitor_event.event_id = event.id
    JOIN olympics.games_competitor ON competitor_event.competitor_id = games_competitor.id
    JOIN olympics.person_region ON games_competitor.person_id = person_region.person_id
    JOIN olympics.noc_region ON person_region.region_id = noc_region.id
WHERE
    medal.medal_name = 'Gold'
    AND event.event_name = 'Football'
GROUP BY Country
ORDER BY Gold_Medals DESC
LIMIT 10;

-- 3-Listar con la misma query el país con más participaciones

--y el país con menos participaciones en los juegos olímpicos (2p)

--tener en cuenta que es oir evento

WITH appearances_by_region AS (
        SELECT
            noc_region.region_name AS Country,
            COUNT(*) AS Participations
        FROM olympics.medal
            JOIN olympics.competitor_event ON medal.id = competitor_event.medal_id
            JOIN olympics.event ON competitor_event.event_id = event.id
            JOIN olympics.games_competitor ON competitor_event.competitor_id = games_competitor.id
            JOIN olympics.person_region ON games_competitor.person_id = person_region.person_id
            JOIN olympics.noc_region ON person_region.region_id = noc_region.id
        GROUP BY Country
    )
SELECT
    Country,
    Participations
FROM (
        SELECT
            Country,
            Participations,
            RANK() OVER (
                ORDER BY
                    Participations DESC
            ) AS Participation_Rank_Max,
            RANK() OVER (
                ORDER BY
                    Participations ASC
            ) AS Participation_Rank_Min
        FROM
            appearances_by_region
    ) AS appearances_by_region_ranked
WHERE
    Participation_Rank_Max = 1
    OR Participation_Rank_Min = 1;

--4-Crear una vista en la que se muestren entradas del tipo

--(país, deporte, medallas de oro, medallas de plata,

--medallas de bronce, participaciones sin medallas) para cada país y deporte (2.5p)

DROP VIEW IF EXISTS MedalsByCountryAndSport;

CREATE VIEW
    MedalsByCountryAndSport AS
SELECT
    noc_region.region_name AS Country,
    event.event_name AS Sport,
    COUNT(
        CASE
            WHEN medal.medal_name = 'Gold' THEN 1
        END
    ) AS Gold_Medals,
    COUNT(
        CASE
            WHEN medal.medal_name = 'Silver' THEN 1
        END
    ) AS Silver_Medals,
    COUNT(
        CASE
            WHEN medal.medal_name = 'Bronze' THEN 1
        END
    ) AS Bronze_Medals,
    COUNT(
        CASE
            WHEN medal.medal_name IS NULL THEN 1
        END
    ) AS Participations_No_Medals
FROM olympics.noc_region
    JOIN olympics.person_region ON noc_region.id = person_region.region_id
    JOIN olympics.games_competitor ON person_region.person_id = games_competitor.person_id
    JOIN olympics.competitor_event ON games_competitor.id = competitor_event.competitor_id
    JOIN olympics.event ON competitor_event.event_id = event.id
    LEFT JOIN olympics.medal ON competitor_event.competitor_id = medal.id
GROUP BY Country, Sport;

--5-Crear un procedimiento que reciba como parámetro el nombre de un país y devuelva la cantidad total

--(sumando todos los deportes) de medallas de oro, plata y bronce ganadas por ese país.

--Puede usar la vista creada en el punto anterior, va a ser mucho más fácil. (1.5

DROP PROCEDURE IF EXISTS MedalsByCountry;

DELIMITER //

CREATE PROCEDURE MEDALSBYCOUNTRY(IN COUNTRYNAME VARCHAR
(255)) BEGIN SELECT 
	SELECT --selecciono y sumo  las medallas de oro, plata y bronce ganadas por ese país
	Country,
	SUM(Gold_Medals) AS Gold_Medals,
	SUM(Silver_Medals) AS Silver_Medals,
	SUM(Bronze_Medals) AS Bronze_Medals,
	SUM(Participations_No_Medals) AS Participations_No_Medals
	FROM
	    MedalsByCountryAndSport --uso la vista del ejerc anterior
	WHERE Country = CountryName;
	--filtro por el pais que me pasan como parametro
	END 


DELIMITER ;

--6

--a-Actualizar la tabla `event` para que tenga una columna `sport_name` con el nombre del deporte.

-- Además introducir el nombre de deporte correspondiente (1p)

ALTER TABLE `event`
ADD
    COLUMN `sport_name` VARCHAR(255) NULL AFTER `event_name`;

UPDATE `event`
SET `sport_name` = 'Basketball'
WHERE `event`.`id` = 1;

-- b-Eliminar la columna `sport_id` de la tabla `event` (0.25p)

ALTER TABLE `event` DROP COLUMN `sport_id`;

--Eliminar la tabla `sport` (0.25p)

DROP TABLE `sport`;
